<template>
    <v-card elevation="2" class="pa-4">Quiz admin users</v-card>
</template>

<script>
export default {}
</script>
