<template>
    <div class="app-admin">Admin</div>
</template>

<script>
export default {
    name: 'AppAdmin',

    metaInfo: {
        title: 'Admin',
    },
}
</script>
