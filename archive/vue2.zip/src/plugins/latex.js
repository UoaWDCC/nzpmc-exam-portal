import Vue from 'vue'
import VueLaTeX2JS from 'latex2vue'
Vue.use(VueLaTeX2JS)

export default VueLaTeX2JS
